export default { hello: "bonjour" };
