import assert from "node:assert";
import test, { after, before, describe } from "node:test";
import { convertV4MiniflareOptions, Miniflare } from "miniflare";

describe("worker", () => {
	/**
	 * @type {Miniflare}
	 */
	let worker;

	before(async () => {
		worker = new Miniflare(
			convertV4MiniflareOptions({
				modules: [
					{
						type: "ESModule",
						path: "src/index-with-imports.js",
					},
					{
						type: "ESModule",
						path: "src/say-hello.js",
					},
				],
			})
		);
		try {
			await worker.ready;
		} catch (e) {
			console.error(e);
		}
	});

	test("hello world", async () => {
		assert.strictEqual(
			await (await worker.dispatchFetch("http://example.com/path")).text(),
			"Hello from http://example.com/path"
		);
	});

	after(async () => {
		await worker.dispose();
	});
});
